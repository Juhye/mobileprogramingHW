package com.cookandroid.TestActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.Vector;

public class SecondActivity extends Activity {
    Vector<String> ID = new Vector<String>(10);
    Vector<String> PASSWORD = new Vector<String>(10);
    Vector<String> NAME = new Vector<String>(10);
    Vector<String> ADDRESS = new Vector<String>(10);
    Vector<String> PHONE = new Vector<String>(10);
    Button btnReturn = findViewById(R.id.register_register);

    EditText register_password=findViewById(R.id.register_password);
    EditText register_id=findViewById(R.id.register_id);
    EditText register_name=findViewById(R.id.register_name);
    EditText register_phone=findViewById(R.id.register_phone);
    EditText register_address=findViewById(R.id.register_address);
/*    public void onSubmitClicked(View v)
    {
        String pass = register_password.getText().toString();
        if(TextUtils.isEmpty(pass) || pass.length() < 8)
        {
            register_password.setError("8자리이상입력하세요");
            return;
        }
    }*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        setTitle("회원가입화면");
        btnReturn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String id=register_id.getText().toString();
                ID.addElement(id);
                String pass = register_password.getText().toString();
                PASSWORD.addElement(pass);
                String name = register_name.getText().toString();
                NAME.addElement(name);
                String phone = register_phone.getText().toString();
                PHONE.addElement(phone);
                String address = register_address.getText().toString();
                ADDRESS.addElement(address);
                System.out.printf("로그인 화면으로 되돌아갑니다");
                finish();
            }
        });
    }

}